<!DOCTYPE html>
<html lang="en">
    
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>barbie</title>

    <!-- swiper css link -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"/>

    <!-- font awesome code link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <!-- custom css file link -->
    <link rel="stylesheet" href="css/style1.css">
</head>
    
<body>

<!-- barbie section start -->

<selection class="orders">
    <h1 class="heading-title">barbie cakes</h1>
    <div class="box-container">
        <div class="box">
            <div class="image">
            <img src="images/Barbie/barbie1.webp" alt="">
            </div>
            <div class="content">
                <h3>barbie cake</h3>
                <p>rs. 7,500.00</p>
                <a href="order.php" class="btn">Order now</a>
            </div>
        </div>

        <div class="box">
            <div class="image">
            <img src="images/Barbie/barbie2.webp" alt="">
            </div>
            <div class="content">
                <h3>barbie cake</h3>
                <p>rs. 7,200.00</p>
                <a href="order.php" class="btn">Order now</a>
            </div>
        </div>

        <div class="box">
            <div class="image">
            <img src="images/Barbie/barbie9.jpg" alt="">
            </div>
            <div class="content">
                <h3>barbie cake</h3>
                <p>rs. 8,000.00</p>
                <a href="order.php" class="btn">Order now</a>
            </div>
        </div>

        <div class="box">
            <div class="image">
            <img src="images/Barbie/barbie7.jpg" alt="">
            </div>
            <div class="content">
                <h3>barbie cake</h3>
                <p>rs. 6,300.00</p>
                <a href="order.php" class="btn">Order now</a>
            </div>
        </div>

        <div class="box">
            <div class="image">
            <img src="images/Barbie/barbie6.webp" alt="">
            </div>
            <div class="content">
                <h3>barbie cake</h3>
                <p>rs. 4,500.00</p>
                <a href="order.php" class="btn">Order now</a>
            </div>
        </div>

        <div class="box">
            <div class="image">
            <img src="images/Barbie/barbie8.jpg" alt="">
            </div>
            <div class="content">
                <h3>barbie cake</h3>
                <p>rs. 4,500.00</p>
                <a href="order.php" class="btn">Order now</a>
            </div>
        </div>

        
    </div><br>
    <center><a href="home.php" class="btn">Back to home</a></center>
</selection>

<!-- barbie section ends -->
<br><br><br>
<!-- footer section starts -->

<section class="footer">
    <div class="box-container">
        <div class="box">
            <h3>quick links</h3>
            <a href="home.php"><i class="fas fa-angle-right"></i>home</a>
            <a href="about.php"><i class="fas fa-angle-right"></i>about us</a>
            <a href="order.php"><i class="fas fa-angle-right"></i>order</a>
            <a href="contact.php"><i class="fas fa-angle-right"></i>contact us</a>
        </div>
        <!-- <div class="box"> 
            <h3>extra links</h3>
            <a href="#"><i class="fas fa-angle-right"></i>ask questions</a>
            <a href="#"><i class="fas fa-angle-right"></i>about us</a>
            <a href="#"><i class="fas fa-angle-right"></i>privacy policy</a>
            <a href="#"><i class="fas fa-angle-right"></i>terms of use</a>
        </div>-->
        <div class="box"> 
            <h3>quick links</h3>
            <a href="birthday.php"><i class="fas fa-angle-right"></i>bithday cakes</a>
            <a href="cup.php"><i class="fas fa-angle-right"></i>cupcakes</a>
            <a href="eggless.php"><i class="fas fa-angle-right"></i>eggless cakes</a>
            <a href="wedding.php"><i class="fas fa-angle-right"></i>wedding cakes</a>
        </div>
        <div class="box">
            <h3>follow us</h3>
            <a href="#"><i class="fab fa-facebook-f"></i>facebook</a>
            <a href="#"><i class="fab fa-twitter"></i>twitter</a>
            <a href="#"><i class="fab fa-instagram"></i>instagram</a>
            <a href="#"><i class="fab fa-linkedin"></i>linkedin</a>
        </div>
    </div>

<div class="credit">created by <span>miss nawodya, web designer</span> | all rights reserved!</div>
</section>

<!-- footer section ends -->

</body>
</html>
