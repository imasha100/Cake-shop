<!DOCTYPE html>
<html lang="en">
    
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>about</title>

    <!-- swiper css link -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"/>

    <!-- font awesome code link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <!-- custom css file link -->
    <link rel="stylesheet" href="css/style1.css">
    
</head>
    
<body>
    
<!-- header section start -->
<section class="header">

<a href="home.html" class="logo">Cakes.</a>

<nav class="navbar">
    <a href="home.php">home</a>
    <a href="product.php">Products</a>
    <a href="about.php">about us</a>
    <a href="order.php">Order</a>
    <a href="contact.php">contact us</a>
    <a href="http://localhost/websitenew/Admin/Login/login.html">Admin</a>
</nav>
<div id="menu-btn" class="fas fa-bars"></div>
</section>

<!-- header section end-->

<div class="heading" style="background:url(images/c5.jpg) no-repeat">
    <h1>about us</h1>
</div>

<!-- about section start -->

<section class="about">
    <div class="image">
        <img src="images/f9.webp" alt="">
    </div>

    <div class="content">
        <h3>why chosse us?</h3>
        <p>Welcome to our esteemed cake shop, where every slice tells a story of passion, creativity, and unparalleled taste. We take immense pride in presenting to you not just cakes, but experiences that linger on your taste buds and memories alike.</P> 
        <p>At our bakery, we believe in crafting more than just confections; we create moments of joy, celebration, and togetherness. With our commitment to quality, innovation, and customer satisfaction, we stand as a beacon of excellence in the world of baking. As you step into our delightful realm of sweetness, you'll discover why choosing us isn't just about buying a cake.... it's about embracing a journey of culinary delight unlike any other</p>
        <div class="icons-container">
            <div class="icons">
                <i class="fas fa-map"></i>
                <span>top destinations</span>
            </div>
            <div class="icons">
                <i class="fas fa-hand-holding-usd"></i>
                <span>afferable prices</span>
            </div>
            <div class="icons">
                <i class="fas fa-headset"></i>
                <span>supply to demand</span>
            </div>
        </div>
    </div>
</section>

<!-- about section start -->

<!-- reviews section starts -->

<selection class="reviews">
    <div class="swiper reviews-slider">
        <div class="swiper-wrapper">
            <div class="swiper-slider slide">
                <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                </div>
                <p>"Visiting this cake shop was truly an unforgettable experience. The passion and dedication poured into each slice were evident from the first bite. I left not just with a cake but with cherished memories of joy and indulgence."</p>
                <h3>Shamodya</h3>
                <span>customer</span>
            </div>

            <div class="swiper-slider slide">
                <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                </div>
                <p>"Choosing this bakery for my special occasion was the best decision I made. The cakes were not only delicious but also beautifully presented. They made my celebration truly memorable, and I'll definitely be returning for more."</p>
                <h3>Hansanee</h3>
                <span>customer</span>
            </div>

            <div class="swiper-slider slide">
                <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                </div>
                <p>"The commitment to quality and customer satisfaction at this cake shop is unparalleled. From the moment I walked in, I felt welcomed and valued. The staff went above and beyond to ensure I found the perfect cake, and it exceeded all expectations."</p>
                <h3>H. mendis</h3>
                <span>customer</span>
            </div>

            <div class="swiper-slider slide">
                <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                </div>
                <p>"I'm continually amazed by the innovation and creativity displayed in the cakes at this bakery. Each visit brings new flavors and designs to explore, making it an exciting culinary adventure every time. I wouldn't hesitate to recommend this place to anyone seeking exceptional baked goods."</p>
                <h3>thilina</h3>
                <span>customer</span>
            </div>
        </div>
    </div>
</selection>

<!-- reviews section ends -->

<br><br><br>

<!-- footer section starts -->

<section class="footer">
    <div class="box-container">
        <div class="box">
            <h3>quick links</h3>
            <a href="home.html"><i class="fas fa-angle-right"></i>home</a>
            <a href="about.php"><i class="fas fa-angle-right"></i>about</a>
            <a href="order.php"><i class="fas fa-angle-right"></i>order</a>
            <a href="contact.php"><i class="fas fa-angle-right"></i>contact us</a>
        </div>
        <!-- <div class="box"> 
            <h3>extra links</h3>
            <a href="#"><i class="fas fa-angle-right"></i>ask questions</a>
            <a href="#"><i class="fas fa-angle-right"></i>about us</a>
            <a href="#"><i class="fas fa-angle-right"></i>privacy policy</a>
            <a href="#"><i class="fas fa-angle-right"></i>terms of use</a>
        </div>-->
        <div class="box"> 
            <h3>quick links</h3>
            <a href="birthday.php"><i class="fas fa-angle-right"></i>bithday cakes</a>
            <a href="cup.php"><i class="fas fa-angle-right"></i>cupcakes</a>
            <a href="eggless.php"><i class="fas fa-angle-right"></i>eggless cakes</a>
            <a href="wedding.php"><i class="fas fa-angle-right"></i>wedding cakes</a>
        </div>
        <div class="box">
            <h3>follow us</h3>
            <a href="#"><i class="fab fa-facebook-f"></i>facebook</a>
            <a href="#"><i class="fab fa-twitter"></i>twitter</a>
            <a href="#"><i class="fab fa-instagram"></i>instagram</a>
            <a href="#"><i class="fab fa-linkedin"></i>linkedin</a>
        </div>
    </div>

<div class="credit">created by <span>miss nawodya, web designer</span> | all rights reserved!</div>
</section>

<!-- footer section ends -->


<!--swiper js link -->
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>

<!-- custom js file link -->
<script src="js/script1.js"></script>

</body>
</html>
