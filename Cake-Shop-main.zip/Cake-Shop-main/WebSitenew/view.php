<?php 
include "connection.php";

    $sql = "SELECT * FROM order_form";
    $result = $conn->query($sql);

?>
<!DOCTYPE html>
<html>
<head>
 <title>View Page</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<style>
    body {
	text-align : center;
	font-size : 18px;
	background-color : #171616;
}

h2 {
	font-family: Times New Roman;
	font-size : 50px;
	color: white;
	}

table {
    color: white;
}

</style>
</head>

<body>
<center><h2>Order Table</h2>
<hr width= "800px" size="5" color="gray"><br></center>
<table border="1" >
 <tr>
 <th>ID</th>
 <th>Name</th>
 <th>Email</th>
 <th>Phone</th>
 <th>Address</th>
 <th>CakeType</th>
 <th>Size</th>
 <th>Flavour</th>
 <th>Fillings</th>
 <th>RequiredDate</th>
 <th>Payment</th>
 </tr>
 </thead>
 <tbody> 
 <?php
 if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
    ?>
        <tr>
        <td><?php echo $row['id']; ?></td>
        <td><?php echo $row['name']; ?></td>
        <td><?php echo $row['email']; ?></td>
        <td><?php echo $row['phone']; ?></td>
        <td><?php echo $row['address']; ?></td>
        <td><?php echo $row['cake_type']; ?></td>
        <td><?php echo $row['size']; ?></td>
        <td><?php echo $row['flavour']; ?></td>
        <td><?php echo $row['fillings']; ?></td>
        <td><?php echo $row['redate']; ?></td>
        <td><?php echo $row['payment']; ?></td>

        <td><a class="btn btn-info" href="update.php?id=<?php echo $row['id'];
        
        ?>">Edit</a>&nbsp;<a class="btn btn-danger" href="delete.php?id=<?php echo $row['id'];
        ?>">Delete</a></td>
        </tr> 
    <?php 
    }
 }
 ?> 
 </tbody>
</table>
</div> 
</body>
</html>
