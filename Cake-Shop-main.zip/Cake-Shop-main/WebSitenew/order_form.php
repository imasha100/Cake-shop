<?php

    include "connection.php";


    if(isset($_POST['send'])){
        $name = $_POST['name'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];
        $address = $_POST['address'];
        $caketype = $_POST['cakeType'];
        $size = $_POST['size'];
        $flavour = $_POST['flavour'];
        $filling = $_POST['filling'];
        $date = $_POST['requiredDate'];
        $payment = $_POST['payment'];

        $sql = "INSERT INTO order_form (name, email, phone, address, cake_type, size, flavour, fillings, redate, payment)
        VALUES('$name', '$email', '$phone', '$address', '$caketype', '$size', '$flavour', '$filling', '$date', '$payment')";

                 $result = $conn->query($sql);
                     if ($result == TRUE) {
                         echo "New record created successfully.";
                         header('location:order.php');
                     }
                     else{
                         echo "Error:". $sql . "<br>". $conn->error;
                     } 

                $conn->close(); 

        }

?>
