<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>order</title>

    <!-- swiper css link -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"/>

    <!-- font awesome code link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <!-- custom css file link -->
    <link rel="stylesheet" href="css/style1.css">
    
</head>
<body>
    
<!-- header section start -->
<section class="header">

<a href="home.php" class="logo">Cakes.</a>

<nav class="navbar">
    <a href="home.php">home</a>
    <a href="product.php">Products</a>
    <a href="about.php">about us</a>
    <a href="order.php">Order</a>
    <a href="contact.php">contact us</a>
    <a href="http://localhost/websitenew/Admin/Login/login.html">Admin</a>
</nav>
<div id="menu-btn" class="fas fa-bars"></div>
</section>



<!-- header section end-->

<div class="heading" style="background:url(images/c14.jpg) no-repeat">
    <h1>Order</h1>
</div>

<!-- order section starts -->

<section class="ordering">
    <h1 class="heading-title">oredr your cakes!</h1>
    <form action="order_form.php" method="POST" class="order-form">

        <div class="flex">
            <div class="inputBox">
                <span>name: </span>
                <input autocomplete="off" type="text" placeholder="enter your name" name="name" required>
            </div>

            <div class="inputBox">
                <span>email: </span>
                <input autocomplete="off" type="email" placeholder="enter your email" name="email" required>
            </div>

            <div class="inputBox">
                <span>phone: </span>
                <input autocomplete="off" type="number" placeholder="enter your number" name="phone" required>
            </div>

            <div class="inputBox">
                <span>address: </span>
                <input autocomplete="off" type="text" placeholder="enter your address" name="address" required>
            </div>

            <div class="inputBox">
                <span>type of cake: </span>
                <input autocomplete="off" type="text" placeholder="enter your cake type" name="cakeType" required>
            </div>

            <div class="inputBox">
                <span>size: </span>
                <input autocomplete="off" type="text" placeholder="enter cake size" name="size" required>
            </div>

            <div class="inputBox">
                <span>flavour: </span>
                <input autocomplete="off" type="text" placeholder="enter your cake flavor" name="flavour" required>
            </div>

            <div class="inputBox">
                <span>fillings: </span>
                <input autocomplete="off" type="text" placeholder="enter your fav topping" name="filling" required>
            </div>

            <div class="inputBox">
                <span>required date: </span>
                <input type="date" name="requiredDate" required>
            </div>

            <div class="inputBox">
                <span>payment information: </span>
                <input autocomplete="off" type="text" placeholder="enter your payment type" name="payment" required>
            </div>
        </div>
        <br><br>
        <center><input type="submit" value="submit" class="btn" name="send"></center>
    </form>
</section>

<!-- order section ends -->


<!-- footer section starts -->

<section class="footer">
    <div class="box-container">
        <div class="box">
            <h3>quick links</h3>
            <a href="home.php"><i class="fas fa-angle-right"></i>home</a>
            <a href="about.php"><i class="fas fa-angle-right"></i>about</a>
            <a href="order.php"><i class="fas fa-angle-right"></i>order</a>
            <a href="contact.php"><i class="fas fa-angle-right"></i>contact us</a>
        </div>
        <!-- <div class="box"> 
            <h3>extra links</h3>
            <a href="#"><i class="fas fa-angle-right"></i>ask questions</a>
            <a href="#"><i class="fas fa-angle-right"></i>about us</a>
            <a href="#"><i class="fas fa-angle-right"></i>privacy policy</a>
            <a href="#"><i class="fas fa-angle-right"></i>terms of use</a>
        </div> -->
        <div class="box"> 
            <h3>quick links</h3>
            <a href="birthday.php"><i class="fas fa-angle-right"></i>bithday cakes</a>
            <a href="cup.php"><i class="fas fa-angle-right"></i>cupcakes</a>
            <a href="eggless.php"><i class="fas fa-angle-right"></i>eggless cakes</a>
            <a href="wedding.php"><i class="fas fa-angle-right"></i>wedding cakes</a>
        </div>
        <div class="box">
            <h3>follow us</h3>
            <a href="#"><i class="fab fa-facebook-f"></i>facebook</a>
            <a href="#"><i class="fab fa-twitter"></i>twitter</a>
            <a href="#"><i class="fab fa-instagram"></i>instagram</a>
            <a href="#"><i class="fab fa-linkedin"></i>linkedin</a>
        </div>
    </div>

<div class="credit">created by <span>miss nawodya, web designer</span> | all rights reserved!</div>
</section>

<!-- footer section ends -->


<!--swiper js link -->
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>

<!-- custom js file link -->
<script src="js/script1.js"></script>

</body>
</html>