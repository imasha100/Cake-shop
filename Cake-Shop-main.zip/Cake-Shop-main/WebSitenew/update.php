<?php 
include "connection.php";
 
if (isset($_POST['update'])) {
    $User_id = $_POST['user_id'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $caketype = $_POST['cakeType'];
    $size = $_POST['size'];
    $flavour = $_POST['flavour'];
    $filling = $_POST['filling'];
    $date = $_POST['requiredDate'];
    $payment = $_POST['payment'];

 $sql = "UPDATE `order_form` SET `name`='$name',`email`='$email',`phone`='$phone',`address`='$address',`cake_type`='$caketype',`size`='$size',`flavour`='$flavour',`fillings`='$filling',`redate`='$date',`payment`='$payment' WHERE `id`='$User_id'"; 
 
 $result = $conn->query($sql); 
 if ($result == TRUE) {
 echo "Record updated successfully.";
 }else{
 echo "Error:" . $sql . "<br>" . $conn->error;
 }
 } 
 if (isset($_GET['id'])) {
    $user_id = $_GET['id']; 
    $sql = "SELECT * FROM `order_form` WHERE `id`='$user_id'";
    $result = $conn->query($sql); 
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      $name = $row['name'];
      $email = $row['email'];
      $phone = $row['phone'];
      $address = $row['address'];
      $caketype = $row['cake_type'];
      $size = $row['size'];
      $flavour = $row['flavour'];
      $fillings = $row['fillings'];
      $date = $row['redate'];
      $payment = $row['payment'];
      $id = $row['id'];
    } 
    ?>
<html>
   <head>
      <style>
         body {
            text-align : center;
            font-size : 20px;
            background-color : gray;
         }

         h2 {
            font-family: Times New Roman;
            font-size : 50px;
            color: white;
         }

         form {
            color:white;
         }

         span{
            font-size: 1.5rem;
            color: var(--light-black);
         }

         input{
            width: 35%;
            padding: .2rem .4rem;
            font-size: 1.2rem;
            text-transform: none;
            margin-top: .5rem;
            border: var(--border);
         }

         .submit input{
            width: 15%;
            padding: .5rem .5rem;
            font-size: 1.2rem;
            text-transform: none;
            margin-top: .5rem;
            border: var(--border);
         }

         .submit button {
            width: 15%;
            padding: .5rem .5rem;
            text-transform: none;
            margin-top: .5rem;
            border: var(--border);
         }
         .submit button a{
            text-decoration:none;
            font-size: 1.2rem;
            color:black;
         }

         #echo{
            color: white;
         }
      

         

      </style>
   </head>
   <body>

    <h2>User Update Form</h2>
    <form action="" method="post">
    <!-- <fieldset> -->
    <!-- <legend>Personal order information:</legend> -->
    
   <span>Name:</span><br>
    <input type="hidden" name="user_id" value="<?php echo $id; ?>">
    <input type="text" name="name" value="<?php echo $name; ?>">
   
    <br>
    
    <span>Email:</span><br>
      <input type="email" name="email" value="<?php echo $email; ?>">
    <br>
    
   <span>Phone:</span><br>
    <input type="number" name="phone" value="<?php echo $phone; ?>">
    <br>
    
   <span>Address:</span> <br>
    <input type="text" name="address" value="<?php echo $address; ?>">
    <br>

   <span>Type of cake: </span><br>
    <input type="text" name="cakeType" value="<?php echo $caketype; ?>">
    <br>

   <span>Size:</span> <br>
    <input type="text" name="size" value="<?php echo $size; ?>">
    <br>

   <span>Flavour:</span> <br>
    <input type="text" name="flavour" value="<?php echo $flavour; ?>">
    <br>

   <span>Fillings:</span> <br>
    <input type="text" name="filling" value="<?php echo $fillings; ?>">
    <br>

   <span>Required date:</span><br>
    <input type="date" name="requiredDate" value="<?php echo $date; ?>">
    <br>

   <span>Payment information:</span> <br>
    <input type="text" name="payment" value="<?php echo $payment; ?>">
    <br>
   

 <br><br>
 <div class="submit">
   <input type="submit" value="Update" name="update">
   <button type="submit"><a href="view.php">Back view page</a></button>
 </div>
 <!-- </fieldset> -->
 <!-- <a href="view.php"><input type="submit" value="Back View page" name="back"></a> -->
 </form> 
 </body>
 </html> 
<?php
 } 
 else{ 
 header('Location: view.php');
 } 
}
?>