<?php

$conn = mysqli_connect('localhost','root','','order_db') or die('connection failed');

?>